export class CreateCarImageDto {}
