export class CreateRentDetailDto {}
